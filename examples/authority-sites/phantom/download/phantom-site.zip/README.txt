Jennu authority site bundle
Built from packs/phantom v0.2.0 - 2026-10-08 22:49 UTC

Contents
  site/            the reference build as shipped: index.html, styles.css,
                   fonts/, MANIFEST.md (sha256 of everything), build log,
                   audit.jsonl (every authority call), refresh-log.md
  pack/            the authority records the build was written from (JSON)
  agent-brief.md   paste-ready brief for a coding agent

Use it
  Open site/index.html in a browser to see the reference build.
  Point your coding agent at agent-brief.md and ask it to build under
  this authority. Verify any file by recomputing its sha256 against
  site/MANIFEST.md.
